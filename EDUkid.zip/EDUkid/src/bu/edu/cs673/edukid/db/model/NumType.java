package bu.edu.cs673.edukid.db.model;

public class NumType {

	private long numtypeId;

	private String numtype;

	public long getNumtypeId() {
		return numtypeId;
	}

	public void setNumtypeId(long numtypeId) {
		this.numtypeId = numtypeId;
	}

	public String getNumtype() {
		return numtype;
	}

	public void setNumtype(String numtype) {
		this.numtype = numtype;
	}
}
