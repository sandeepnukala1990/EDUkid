package bu.edu.cs673.edukid.db.model;

public class Num {

	private long numberId;

	private String number;

	private String numberSound;

	public long getNumberId() {
		return numberId;
	}

	public void setNumberId(long numberId) {
		this.numberId = numberId;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getNumberSound() {
		return numberSound;
	}

	public void setNumberSound(String numberSound) {
		this.numberSound = numberSound;
	}

}
