/** Automatically generated file. DO NOT MODIFY */
package bu.edu.cs673.edukid;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}